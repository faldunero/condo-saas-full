"use client";

import { useState } from "react";
import dataJson from "../../data/admin-mock.json";

type Building = (typeof dataJson.buildings)[number];

export default function AdminHome() {
  const [buildings, setBuildings] = useState<Building[]>(dataJson.buildings);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    address: "",
    commune: "",
    units: 0,
  });

  const isEditing = selectedId !== null;

  function resetForm() {
    setForm({ name: "", address: "", commune: "", units: 0 });
    setSelectedId(null);
  }

  function handleEdit(b: Building) {
    setSelectedId(b.id);
    setForm({
      name: b.name,
      address: b.address,
      commune: b.commune,
      units: b.units,
    });
  }

  function handleDelete(id: string) {
    setBuildings((prev) => prev.filter((b) => b.id !== id));
    if (selectedId === id) {
      resetForm();
    }
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim() || !form.address.trim()) return;

    if (isEditing && selectedId) {
      setBuildings((prev) =>
        prev.map((b) =>
          b.id === selectedId
            ? { ...b, ...form, units: Number(form.units) || 0 }
            : b
        )
      );
    } else {
      const id = `bldg-${Date.now()}`;
      setBuildings((prev) => [
        ...prev,
        {
          id,
          name: form.name,
          address: form.address,
          commune: form.commune,
          units: Number(form.units) || 0,
          city: "Santiago",
          country: "Chile",
        } as Building,
      ]);
    }

    resetForm();
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[2fr,1.2fr]">
      <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 className="text-xl font-semibold">Edificios administrados</h2>
            <p className="mt-1 text-sm text-slate-600">
              Crea, edita y elimina edificios (CRUD en memoria, sin persistencia real).
            </p>
          </div>
        </div>
        <div className="mt-4 overflow-hidden rounded-lg border border-slate-200">
          <table className="min-w-full divide-y divide-slate-200 text-sm">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-4 py-2 text-left font-semibold text-slate-700">Nombre</th>
                <th className="px-4 py-2 text-left font-semibold text-slate-700">Dirección</th>
                <th className="px-4 py-2 text-left font-semibold text-slate-700">Comuna</th>
                <th className="px-4 py-2 text-right font-semibold text-slate-700">Unidades</th>
                <th className="px-4 py-2 text-right font-semibold text-slate-700">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {buildings.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50">
                  <td className="px-4 py-2 text-slate-900">{b.name}</td>
                  <td className="px-4 py-2 text-slate-700">{b.address}</td>
                  <td className="px-4 py-2 text-slate-700">{b.commune}</td>
                  <td className="px-4 py-2 text-right tabular-nums text-slate-900">{b.units}</td>
                  <td className="px-4 py-2 text-right text-xs">
                    <button
                      type="button"
                      onClick={() => handleEdit(b)}
                      className="rounded border border-slate-300 px-2 py-1 text-slate-700 hover:bg-slate-100"
                    >
                      Editar
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(b.id)}
                      className="ml-2 rounded border border-rose-200 px-2 py-1 text-rose-700 hover:bg-rose-50"
                    >
                      Borrar
                    </button>
                  </td>
                </tr>
              ))}
              {buildings.length === 0 && (
                <tr>
                  <td
                    colSpan={5}
                    className="px-4 py-6 text-center text-sm text-slate-500"
                  >
                    No hay edificios aún. Crea el primero usando el formulario.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      <section className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <h2 className="text-lg font-semibold">
          {isEditing ? "Editar edificio" : "Crear nuevo edificio"}
        </h2>
        <p className="mt-1 text-sm text-slate-600">
          Este formulario solo modifica el estado en memoria del frontend. Luego lo conectaremos a una API real.
        </p>
        <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-sm">
          <div>
            <label className="block text-slate-700">Nombre</label>
            <input
              className="mt-1 w-full rounded border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-slate-900 focus:outline-none"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              placeholder="Edificio Los Alerces"
              required
            />
          </div>
          <div>
            <label className="block text-slate-700">Dirección</label>
            <input
              className="mt-1 w-full rounded border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-slate-900 focus:outline-none"
              value={form.address}
              onChange={(e) =>
                setForm((f) => ({ ...f, address: e.target.value }))
              }
              placeholder="Las Condes 1234, Las Condes, RM"
              required
            />
          </div>
          <div>
            <label className="block text-slate-700">Comuna</label>
            <input
              className="mt-1 w-full rounded border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-slate-900 focus:outline-none"
              value={form.commune}
              onChange={(e) =>
                setForm((f) => ({ ...f, commune: e.target.value }))
              }
              placeholder="Las Condes"
            />
          </div>
          <div>
            <label className="block text-slate-700">Unidades</label>
            <input
              type="number"
              min={0}
              className="mt-1 w-full rounded border border-slate-300 px-3 py-2 text-sm shadow-sm focus:border-slate-900 focus:outline-none"
              value={form.units}
              onChange={(e) =>
                setForm((f) => ({ ...f, units: Number(e.target.value) }))
              }
            />
          </div>
          <div className="flex items-center gap-3 pt-2">
            <button
              type="submit"
              className="rounded bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800"
            >
              {isEditing ? "Guardar cambios" : "Crear edificio"}
            </button>
            {isEditing && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs text-slate-500 hover:text-slate-700"
              >
                Cancelar edición
              </button>
            )}
          </div>
        </form>
      </section>
    </div>
  );
}
