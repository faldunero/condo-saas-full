import type { ReactNode } from "react";

export default function ResidenteLayout({ children }: { children: ReactNode }) {
  return (
    <section className="min-h-[calc(100vh-56px)] bg-slate-100 text-slate-900">
      <div className="mx-auto flex max-w-4xl flex-col gap-4 px-4 py-6">
        <h1 className="text-lg font-semibold">Condo SaaS · Residente</h1>
        <main>{children}</main>
      </div>
    </section>
  );
}
