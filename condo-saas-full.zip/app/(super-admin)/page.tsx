export default function SuperAdminHome() {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6">
      <h2 className="text-xl font-semibold">Dashboard Super Admin</h2>
      <p className="mt-2 text-slate-300">
        Aquí podrás gestionar tenants, planes y la operación global del SaaS.
      </p>
    </div>
  );
}
