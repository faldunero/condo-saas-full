import type { ReactNode } from "react";

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <section className="min-h-[calc(100vh-56px)] bg-slate-50 text-slate-900">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-6">
        <h1 className="text-lg font-semibold">Condo SaaS · Administradora</h1>
        <main>{children}</main>
      </div>
    </section>
  );
}
