export default function ResidenteHome() {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
      <h2 className="text-xl font-semibold">Portal de Residente</h2>
      <p className="mt-2 text-slate-600">
        Aquí los residentes verán sus gastos comunes, reservas y comunicaciones.
      </p>
    </div>
  );
}
