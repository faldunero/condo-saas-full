import type { ReactNode } from "react";

export default function SuperAdminLayout({ children }: { children: ReactNode }) {
  return (
    <section className="min-h-[calc(100vh-56px)] bg-slate-950 text-slate-50">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-6">
        <h1 className="text-lg font-semibold">Condo SaaS · Super Admin</h1>
        <main>{children}</main>
      </div>
    </section>
  );
}
